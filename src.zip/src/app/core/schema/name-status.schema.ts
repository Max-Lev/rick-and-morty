// import { gql } from "apollo-angular";

// export const NAME_STATUS_QUERY = gql`
// query getNameStatus($name:String, $status: String){
//     characters(filter:{name:$name,status:$status}){
//       info{
//       count,
//       pages,
//       prev,
//       next,
//     },
//       results{
//         id
//         name
//         status
//         species
//         gender
//         image,
//         type
//       }
//     }
//   }`;
